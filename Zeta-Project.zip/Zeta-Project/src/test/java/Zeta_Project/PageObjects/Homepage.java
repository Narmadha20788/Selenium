package Zeta_Project.PageObjects;

public interface Homepage {

	 void fromCityOrigin(String fromcity);
	 
	 void toCityDestination(String toCity);
	 
	 void selectFromPlace(String fromPlace);
	 
	 void selectToPlace(String toPlace);
	 
	// void fromDateSelection(String fromDate);
	 
	 //void searchButton(String searchButton);
	 
	 
	 
	 
}
